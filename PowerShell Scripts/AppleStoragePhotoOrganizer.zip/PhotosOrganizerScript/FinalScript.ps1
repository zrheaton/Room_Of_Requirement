﻿# Initial setup
$sourceDirectoryPath = "C:\Users\zrhea\Desktop\IphoneBackupSafe\IphonePhotos"
$intermediateDirectoryPath = "C:\Users\zrhea\Desktop\PhotosOrganizerScript\StagingPoint"
$finalDestinationPath = "C:\Users\zrhea\Desktop\PhotosOrganizerScript\Output"

# Regex patterns for year and month extraction
$yearPattern = "\d{2}([a-zA-Z]{3})(\d{4})_\d{4}[A-Z]?"
$monthPattern = "\d{2}([a-zA-Z]{3})\d{4}_\d{4}[A-Z]?"
$monthNames = @("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

# Step 1: Rename and move files to intermediate directory
Get-ChildItem -Path $sourceDirectoryPath | ForEach-Object {
    $modifiedTime = $_.LastWriteTime
    $baseName = $modifiedTime.ToString("ddMMMyyyy_HHmm")
    $extension = $_.Extension
    $suffix = 64

    do {
        $suffix++
        $formattedDate = $baseName + [char]$suffix + $extension
        $newFullPath = Join-Path $intermediateDirectoryPath $formattedDate
    } while (Test-Path $newFullPath)

    Rename-Item $_.FullName -NewName $formattedDate
    Move-Item (Join-Path $sourceDirectoryPath $formattedDate) -Destination $intermediateDirectoryPath
    Write-Host "Moved and renamed $($_.Name) to $intermediateDirectoryPath\$formattedDate"
}

# Step 2: Sort files into directories by year
Get-ChildItem -Path $intermediateDirectoryPath | ForEach-Object {
    if ($_.Name -match $yearPattern) {
        $year = $Matches[2]
        $yearFolderPath = Join-Path $finalDestinationPath $year

        if (-not (Test-Path $yearFolderPath)) {
            New-Item -ItemType Directory -Path $yearFolderPath
        }

        $destinationPath = Join-Path $yearFolderPath $_.Name
        Move-Item $_.FullName -Destination $destinationPath
    } else {
        Write-Warning "Filename format not matched: $($_.Name)"
    }
}

# Step 3: Further organize files into subdirectories by month within each year folder
Get-ChildItem -Path $finalDestinationPath -Directory | ForEach-Object {
    $yearFolderPath = $_.FullName

    Get-ChildItem -Path $yearFolderPath | ForEach-Object {
        if ($_.Name -match $monthPattern) {
            $monthAbbrev = $Matches[1]
            if ($monthAbbrev -in $monthNames) {
                $monthFolderPath = Join-Path $yearFolderPath $monthAbbrev

                if (-not (Test-Path $monthFolderPath)) {
                    New-Item -ItemType Directory -Path $monthFolderPath
                }

                $destinationPath = Join-Path $monthFolderPath $_.Name
                Move-Item $_.FullName -Destination $destinationPath
            } else {
                Write-Warning "Month abbreviation not recognized: $monthAbbrev in file $($_.Name)"
            }
        } else {
            Write-Warning "Filename format not matched: $($_.Name)"
        }
    }
}
